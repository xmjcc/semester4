﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1_wenpingwang.models
{
    public enum Audience
    {
        world,
        group,
        special
    }
}
